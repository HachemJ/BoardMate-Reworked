package ca.mcgill.ecse321.BoardGameManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardGameManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
