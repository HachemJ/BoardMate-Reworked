package ca.mcgill.ecse321.BoardGameManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BoardGameManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BoardGameManagementApplication.class, args);
	}

}
